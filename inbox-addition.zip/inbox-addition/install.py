"""Run from your existing GitHub/Codespaces project root: python inbox-addition/install.py"""
from pathlib import Path
import json, shutil, re
root=Path.cwd(); bundle=Path(__file__).resolve().parent
inbox=root/'src/components/Inbox.tsx'
if not inbox.exists():raise SystemExit('Run this command from the app folder containing package.json and src/.')
s=inbox.read_text(); original=s
if "from './EmailActivity'" not in s:
    marker='<div className="p-4 sm:p-6">'
    if marker not in s:raise SystemExit('Inbox layout differs; no changes made. Please share the current Inbox.tsx.')
    nav=re.search(r"\{ key: 'bookings', label: 'Booked Appointments', icon: Calendar \},",s)
    if not nav:raise SystemExit('Inbox tabs differ; no changes made. Please share the current Inbox.tsx.')
    s="import { EmailActivity } from './EmailActivity';\n"+s
    s=s.replace("useState<'bookings' | 'replies' | 'ai-setter'>", "useState<'bookings' | 'replies' | 'ai-setter' | 'email-activity' | 'activity' | 'calendar'>",1)
    s=s.replace(nav.group(),nav.group()+"\n              { key: 'email-activity', label: 'Email Activity', icon: MessageSquare },",1)
    s=s.replace(marker,marker+"\n          {activeTab === 'email-activity' && <EmailActivity theme={theme} />}\n",1)
# Validate every intended overwrite before applying anything.
files=list((bundle/'patch').rglob('*'));files=[f for f in files if f.is_file()]
backup=root/'inbox-addon-backup'
for target in [inbox]+[root/f.relative_to(bundle/'patch') for f in files]:
    if target.exists():
        dest=backup/target.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():shutil.copy2(target,dest)
inbox.write_text(s)
for f in files:
    target=root/f.relative_to(bundle/'patch');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
print('Added Email Activity tab and server files. Original Inbox saved in inbox-addon-backup.')
print('Next: npm install nodemailer@10.0.1 imapflow@2.0.0 mailparser@3.9.23 dompurify@3.4.15')
print('Use the dependency versions in README if this installer was updated.')
