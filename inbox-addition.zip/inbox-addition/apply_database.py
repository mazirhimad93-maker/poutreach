"""Windows CMD: python -m pip install "psycopg[binary]" ; python apply_database.py"""
from pathlib import Path
import getpass
import psycopg
sql=Path(__file__).with_name('patch')/'supabase/migrations/20260908090000_inbox_addition.sql'
print('Use the Postgres connection URI for your EXISTING outreach Supabase project.')
uri=getpass.getpass('Postgres connection URI (hidden): ')
try:
    with psycopg.connect(uri,connect_timeout=15) as connection:
        with connection.cursor() as cursor:cursor.execute(sql.read_text())
    print('Inbox tables and activity view installed. Existing messages and channels preserved.')
except Exception as e:
    print('Database setup failed:',type(e).__name__,'Check the connection URI and database permissions. No credentials printed.')
    raise SystemExit(1)
