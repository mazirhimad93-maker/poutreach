# Add Email Activity to the existing Inbox

This adds one tab to the interface you already use. Booked Appointments, Lead Replies, AI Setter Training, campaigns, and the rest of the layout stay in place. The installer supports both supplied Inbox.tsx versions; it stops if their expected layout is not found.

## What you get

- **Email Activity**: sent campaign messages, imported replies and your manual replies, newest first. Filter by sending inbox, campaign, direction, prospect, subject or address. Load older emails without a fixed overall list limit.
- Open a message to read its text or a sanitized email layout. Remote images, tracking pixels, scripts, forms and external navigation are excluded from the preview.
- **Reply from the original sender**: a conversation sent by Jay uses Jay's connected SMTP account. From and recipient are derived on the server from the owned conversation; the browser cannot substitute a different sender. The reply uses In-Reply-To and References headers.
- **Sync replies**: reads each selected original mailbox over secure IMAP. It searches for prospects from that mailbox's most recent 1,000 logged outbound messages, then matches thread headers or an unambiguous prospect/campaign/sender combination. Initial sync looks back 14 days; subsequent syncs resume by IMAP UID. A small batch is processed per inbox per click. If more remains, the interface tells you to sync again.
- A reply found in the master inbox belongs to the ORIGINAL sending mailbox. This addition connects the existing sender inboxes, not the master mailbox. It does not need the master password.
- Duplicate request protection for manual replies. A lost SMTP response is marked for review, not automatically resent.

## What the activity list can prove

Existing campaign sends come from conversation_history. They are labelled “Sent · logged”; this is the workflow's record, not proof of delivery or inbox placement. Unlogged historical sends cannot be reconstructed from this interface alone. New manual replies show sending, sent, failed or unknown.

Subjects beginning Re: are not proof of a real prospect reply. Absence of a warm-up code is also not proof. This importer matches campaign conversations instead of deleting messages based on numbers. Unmatched/ambiguous messages remain in webmail, untouched. It does not mark mail as read or delete anything.

Attachments and mail larger than 1 MB are not imported in this version. Message bodies are bounded to 100 KB text / 200 KB HTML. Replies are plain text and do not attach files. If forwarding removes the original mailbox's copy, it cannot be synced from that inbox; keep that message in the master inbox for review.

## Install in the existing GitHub project (Codespaces terminal)

Download inbox-addition.zip and upload it into the root of the current Codespace, beside package.json. The ZIP contains the inbox-addition/ folder.

```bash
unzip inbox-addition.zip
python inbox-addition/install.py
npm install nodemailer@10.0.1 imapflow@2.0.0 mailparser@3.9.23 dompurify@3.4.15
npm run build
```

The installer adds the component, backend functions and one database migration, and makes three small Inbox.tsx additions (import, tab, tab content plus the tab type). It stores the original changed files under inbox-addon-backup/. Do not commit the backup or uploaded ZIP. It does not replace package.json or your Netlify configuration.

If your netlify.toml already sets a custom functions directory, make sure these new functions are inside that directory. Otherwise Netlify's default is netlify/functions. The .cjs endpoints deliberately use CommonJS even when the app has type=module.

## One-time database installation

Use the EXISTING outreach project: https://zhlaaaysvzqixnugqbna.supabase.co.

The migration creates two additional tables and a server-only activity view. It does not delete leads, alter inbox activation or change workflow schedules. This needs an actual PostgreSQL database connection; the outreach login password or public API key alone cannot create tables.

Option A — Windows Command Prompt, no SQL editor:

Extract the ZIP into Downloads. Install the Python database driver, then run the included script:

```bat
cd /d "%USERPROFILE%\Downloads\inbox-addition"
python -m pip install "psycopg[binary]"
python apply_database.py
```

Paste your outreach project's PostgreSQL connection URI when asked. Input is hidden and not saved. Use the database password in the URI, with special characters URL-encoded. A Supabase session-pooler URI can be used if the direct database host is unreachable. Do not paste database credentials into chat or the GitHub repository.

Option B — if you already use Supabase CLI migrations for this repository, apply `20260908090000_inbox_addition.sql` through that existing migration process. Do not blindly run all historical migrations from an old uploaded project against the live database.

## Netlify environment variables

Keep the frontend variables already working:

- VITE_SUPABASE_URL
- VITE_SUPABASE_ANON_KEY

Add these with Functions scope:

- SUPABASE_URL = https://zhlaaaysvzqixnugqbna.supabase.co
- SUPABASE_SERVICE_ROLE_KEY = the service-role key for that SAME project

The service-role key is server-only. Never prefix it with VITE_, put it in frontend source, or commit it. Each API call validates the logged-in user's Supabase token, scopes all conversation and channel reads to that user, and retrieves only that user's SMTP/IMAP credentials server-side. No credentials are included in this ZIP.

Use a current supported Node runtime (the existing Node 22 setup is suitable). The user token—not a database admin key—is sent from the browser.

## Publish the addition

After the database step and environment variables are ready, commit only the intended app files:

```bash
git add src/components/Inbox.tsx src/components/EmailActivity.tsx netlify/functions/inbox-api.cjs netlify/functions/inbox-sync.cjs netlify/functions/lib/inbox-core.cjs supabase/migrations/20260908090000_inbox_addition.sql package.json package-lock.json
git commit -m "Add inbox email activity and replies from original sender"
git push origin main
```

Netlify should deploy from that commit using the existing GitHub connection. No new Netlify project, domain or interface redesign is required.

## First check in the interface

1. Open Inbox -> Email Activity. Confirm a known logged send has the expected prospect and original sender.
2. Choose Jay's inbox, then Sync replies. Continue if the result says more messages remain. Once tested, All sender inboxes can sync the connected accounts sequentially; the progress line identifies the current mailbox. You may stop after the current inbox.
3. Open the imported reply. Check From shows Jay's actual email address and To shows the prospect.
4. Type your response. Nothing is sent until you click Send reply.
5. Inspect the new manual reply in Email Activity and, for the first live test, verify it reaches a mailbox you control. SMTP acceptance is not delivery confirmation.

Older records missing channel_id or Message-ID cannot be replied to reliably in-thread. The UI explains this and asks you to sync the original reply; it does not pick an arbitrary sender. Inactive senders are not automatically reactivated. Manual replies do not change the automation's cold-outreach usage counters, cooldown or daily limits.

The addition records imported and manually sent messages into the older conversation_history format when possible so existing workflow history remains available. Manual messages use that legacy table's ai role, but Email Activity explicitly labels them as your replies. If that compatibility write fails, Email Activity retains its own record and displays a warning; inspect the schema before relying on automated follow-up behavior. The current n8n workflow still determines how it responds to recorded replies.

## Validation and limits

Local app production build, reply matching/ambiguity tests, database migration/rerun and view behavior, database access restrictions, original SMTP sender/thread construction, request idempotency, inactive and unowned target rejection, and uncertain send handling were tested with local fixtures. No live Supabase migration, IMAP import, deployment, or SMTP email was performed while preparing the package.

This is a user-triggered reply importer, not an always-running IMAP daemon. The activity list refreshes when idle; fetching new mailbox replies requires Sync replies. It does not import the master inbox's entire warm-up archive, copy outgoing emails into IMAP Sent, or calculate delivery/open tracking.

Official references:
- https://nodemailer.com/message — reply headers and SMTP message fields
- https://imapflow.com/docs/api/imapflow-client/ — read-only mailbox access and UID fetching
- https://supabase.com/docs/guides/database/postgres/row-level-security — view and table access
- https://docs.netlify.com/build/functions/configuration/ — CommonJS function support

Visual browser testing was attempted but the browser binary download was unavailable in this environment. Desktop/mobile visual verification remains part of the deployment check.
