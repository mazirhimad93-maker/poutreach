#!/usr/bin/env bash
set -euo pipefail
cd /workspaces/poutreach
if [ "$(git branch --show-current)" != main ]; then
  echo "Open the main branch before installing this patch."
  exit 1
fi
if ! git diff --quiet -- src/components/EmailActivity.tsx; then
  echo "EmailActivity.tsx has local edits. Commit or back them up first."
  exit 1
fi
cp "$(dirname "${BASH_SOURCE[0]}")/EmailActivity.tsx" src/components/EmailActivity.tsx
npm run build
git add src/components/EmailActivity.tsx
if ! git diff --cached --quiet -- src/components/EmailActivity.tsx; then
  git commit -m "Read email activity using existing authenticated Supabase connection" -- src/components/EmailActivity.tsx
fi
git push origin main
echo "Patch pushed. Wait for Netlify to publish, then refresh Inbox > Email Activity."
